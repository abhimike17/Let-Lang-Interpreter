package ppl;

public class IntBool {

	int i;
	Boolean exp;
	String name;

	public IntBool(int i, Boolean exp) {
		this.i = i;
		this.exp = exp;
		this.name = "intbool";
	}
}
