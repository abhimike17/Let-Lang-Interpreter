package ppl;

import java.io.IOException;

public class main {

	public main(String args[]) throws IOException {
	}
}
