package ppl;

public class IsZeroExp extends LetLangExp{

}
