package ppl;

public class BoolExp extends LetLangExp {

}
